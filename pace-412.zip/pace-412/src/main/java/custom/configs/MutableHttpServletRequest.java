package custom.configs;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.logging.Logger;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

final class MutableHttpServletRequest extends HttpServletRequestWrapper {
	public static final Logger LOGGER = Logger.getLogger(MutableHttpServletRequest.class.getName());
	// holds custom header and value mapping
	private final Map<String, String> customHeaders;
	private ByteArrayOutputStream cachedBytes;
	private String body;
	private Map<String, String[]> parameterMap;
	private static int bufferLength = 1024 * 50;

	public MutableHttpServletRequest(HttpServletRequest request) throws IOException {
		super(request);
		this.customHeaders = new HashMap<String, String>();
		cacheBodyAsString();

		parameterMap = new HashMap<>(super.getParameterMap());
		addParametersFromBody();
	}

	public void putHeader(String name, String value) {
		LOGGER.info("Request Header :\t" + name + ":" + value);
		this.customHeaders.put(name, value);
	}

	public String getHeader(String name) {
		// check the custom headers first
		String headerValue = customHeaders.get(name);

		if (headerValue != null) {
			return headerValue;
		}
		// else return from into the original wrapped object
		return ((HttpServletRequest) getRequest()).getHeader(name);
	}

	public Enumeration<String> getHeaderNames() {
		// create a set of the custom header names
		Set<String> set = new HashSet<String>(customHeaders.keySet());

		// now add the headers from the wrapped request object
		@SuppressWarnings("unchecked")
		Enumeration<String> e = ((HttpServletRequest) getRequest()).getHeaderNames();
		while (e.hasMoreElements()) {
			// add the names of the request headers into the list
			String n = e.nextElement();
			set.add(n);
		}

		// create an enumeration from the set and return
		return Collections.enumeration(set);
	}
	
	@Override
    public ServletInputStream getInputStream() throws IOException {
        return new CachedServletInputStream(cachedBytes.toByteArray());
    }

    @Override
    public BufferedReader getReader() throws IOException {
        return new BufferedReader(new InputStreamReader(this.getInputStream()));
    }

    public String getRequestBodyAsString() {
        return this.body;
    }
    
    @Override
    public String getParameter(String key) {
        Map<String, String[]> parameterMap = getParameterMap();
        String[] values = parameterMap.get(key);
        return values != null && values.length > 0 ? values[0] : null;
    }

    @Override
    public String[] getParameterValues(String key) {
        Map<String, String[]> parameterMap = getParameterMap();
        return parameterMap.get(key);
    }

    @Override
    public Map<String, String[]> getParameterMap() {
        return parameterMap;
    }
    
    private void cacheInputStream() throws IOException {
        cachedBytes = new ByteArrayOutputStream();

        byte[] buffer = new byte[bufferLength];
        int length;
        InputStream is = super.getInputStream();
        while ((length = is.read(buffer)) != -1) {
            cachedBytes.write(buffer, 0, length);
        }
    }
    
    private void cacheBodyAsString() throws IOException {
        if (cachedBytes == null)
            cacheInputStream();
        
        this.body = cachedBytes.toString("UTF-8");
    }
    
    private void addParametersFromBody() {
        if(this.body == null || this.body.isEmpty())
            return;
        
        String[] params = this.body.split("&");

        String[] value = new String[1];
        for (String param : params) {  
            String key = param.split("=")[0];
            value[0] = param.split("=")[1];
            parameterMap.putIfAbsent(key, value);
        }

    }
    
    class CachedServletInputStream extends ServletInputStream {
        private final ByteArrayInputStream buffer;
        
        public CachedServletInputStream(byte[] contents) {
            this.buffer = new ByteArrayInputStream(contents);
        }
        
        @Override
        public int read() {
            return buffer.read();
        }

        @Override
        public boolean isFinished() {
            return buffer.available() == 0;
        }

        @Override
        public boolean isReady() {
            return true;
        }

        @Override
        public void setReadListener(ReadListener listener) {
            throw new RuntimeException("Not implemented");
        }
    }
}