package custom.configs;
import java.io.IOException;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.UUID;
import java.util.logging.Logger;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


//@WebFilter("/AuthenticationFilter")
public class GetSessionFilter implements Filter {

	public static final Logger LOGGER = Logger.getLogger(GetSessionFilter.class.getName());
	
	
	
	private ServletContext context;
	
	public void init(FilterConfig fConfig) throws ServletException {
		System.out.println("AuthenticationFilter initialized...");
		this.context = fConfig.getServletContext();
		LOGGER.info("AuthenticationFilter initialized");
	}
	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		LOGGER.info("i am in dofilter");
		HttpServletRequest req = (HttpServletRequest) request;
		MutableHttpServletRequest mutableRequest = new MutableHttpServletRequest(req);
		
        ResponseWrapper res = new ResponseWrapper((HttpServletResponse) response);
		
        String reqID = UUID.randomUUID().toString();
		mutableRequest.putHeader("ReqId", reqID);
		mutableRequest.setAttribute("ReqId", reqID);
		LOGGER.info("Request Headers For Request ID-"+req.getAttribute("ReqId"));
		printRequestHeaders(mutableRequest);
		printRequestData(mutableRequest);
		
		res.setHeader("ReqId", reqID);
		LOGGER.info("Status Code "+res.getStatus());
		if(res.getStatus()==200) {
			LOGGER.info("Response Headers For Request ID-"+res.getHeader("ReqId"));
			printResponseHeaders(res);
			LOGGER.info("BEFORE"+res.toString()+"AFTER");
			
		}else if(res.getStatus()==412) {
			LOGGER.info("Response Headers For Request ID-"+res.getHeader("ReqId"));
			printResponseHeaders(res);
			LOGGER.info("BEFORE"+res.toString()+"AFTER");
		}
		chain.doFilter(mutableRequest, res);
		
		
	}

	public void destroy() {
		//close any resources here
	}
	
	public void printRequestData(MutableHttpServletRequest req) {
		String remoteAddr = req.getRemoteAddr();
		LOGGER.info("remoteAddr: " + remoteAddr);

		String host = req.getRemoteHost();
		LOGGER.info("Host: " + host);

		String context = req.getContextPath();
		LOGGER.info("context: " + context);

		String reqUri = req.getRequestURI();
		LOGGER.info("reqUri: " + reqUri);

		String requestPath = req.getPathInfo();
		LOGGER.info("requestPath: " + requestPath);
		String requestMethod = req.getMethod();
		LOGGER.info("requestMethod: " + requestMethod);
		String reqBody = req.getRequestBodyAsString();
		LOGGER.info("reqBody: " + reqBody);
	}
	
	public void printRequestHeaders(MutableHttpServletRequest req) {
		  Enumeration names = req.getHeaderNames();
		  if(names == null) {
		    return;
		  }
		    while(names.hasMoreElements()) {
		      String name = (String) names.nextElement();
		       Enumeration values = req.getHeaders(name);
		       if(values != null) {
		         while(values.hasMoreElements()) {
		             String value = (String) values.nextElement();
		             LOGGER.info(name + " : " + value );
		         }
		       }
		    }
		}
	public void printResponseHeaders(HttpServletResponse res) {
		  Collection<String> names = res.getHeaderNames();
		  if(names == null) {
		    return;
		  }
		  Iterator namesIterator = names.iterator();
		  while(namesIterator.hasNext()) {
		   String name = (String)  namesIterator.next();
		    Collection<String> values = res.getHeaders(name);
		    if(values != null) {
		       Iterator valuesIterator = values.iterator();
		       while(valuesIterator.hasNext()) {
		            String value = (String) valuesIterator.next();
		            LOGGER.info(name + " : " + value );         
		       }
		    }
		  }
		}

}